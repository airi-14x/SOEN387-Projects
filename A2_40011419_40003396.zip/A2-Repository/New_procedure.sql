CREATE PROCEDURE `new_procedure` ()
BEGIN
	SELECT id, isbn
    FROM book
END
