/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repository.core;

/**
 *
 * @author Jasmine Latendresse and Airi Chow
 */
public class RepositoryException extends Exception {
    
    RepositoryException(String msg) {
        super(msg);
    }
    
}
